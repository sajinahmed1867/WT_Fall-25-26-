<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="CSS/style.css">
<title>Courses & Marks</title>
</head>
<body>

<div class="box">
<h2>My Courses & Marks</h2>

<table border="1" width="100%">
<tr>
<th>Course</th><th>Marks</th><th>Grade</th>
</tr>
<tr>
<td>Web Technology</td><td>85</td><td>A</td>
</tr>
<tr>
<td>java</td><td>80</td><td>B+</td>
</tr>
<tr>
<td>operating system</td><td>85</td><td>A</td>
</tr>
<tr>
<td>machine learning</td><td>90</td><td>A+</td>
</tr>
<tr>
<td>computer networks</td><td>75</td><td>B</td>
</tr>
<tr>
 <td>math matichs</td><td>75</td><td>B</td>
 
</tr>   
</table>

<h3>Offered Courses</h3>
<ul>
<li>Artificial Intelligence</li>
<li>Machine Learning</li>
<li>Computer Networks</li>
<li>Math Matichs</li>
<li>english</li>
<li>bangladesh studies</li>
<li>microprocessor</li>
</ul>

<a href="dashboard.php">Back</a>
</div>

</body>
</html>
