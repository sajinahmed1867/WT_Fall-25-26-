<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="CSS/style.css">
<title>Contact Faculty</title>
</head>
<body>

<div class="box">
<h2>Contact Faculty</h2>

<input placeholder="Faculty Name">
<textarea placeholder="Write your message"></textarea>

<button onclick="alert('Message Sent ')">
Send
</button>

<a href="dashboard.php">Back</a>
</div>

</body>
</html>
