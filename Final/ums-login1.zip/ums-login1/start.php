<?php
include('Controller/mainController.php');
?>